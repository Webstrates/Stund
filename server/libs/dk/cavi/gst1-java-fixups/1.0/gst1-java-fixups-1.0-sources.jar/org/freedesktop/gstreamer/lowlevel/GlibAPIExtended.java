/*
 * Copyright (c) 2026 Janus Kristensen - CAVI, Center for Advanced
 * Visualization and Interaction - Aarhus University
 *
 * This file is part of gst1-java-fixups.
 *
 * This code is free software: you can redistribute it and/or modify it under the terms of the GNU
 * Lesser General Public License version 3 only, as published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License version 3 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License version 3 along with
 * this work. If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: LGPL-3.0-only
 */
package org.freedesktop.gstreamer.lowlevel;

import com.sun.jna.Library;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.LongByReference;
import java.util.HashMap;

/**
 *
 * @author jbk
 */
public interface GlibAPIExtended extends GlibAPI {
    GlibAPIExtended GLIB_API = GNative.loadLibrary("glib-2.0", GlibAPIExtended.class,
            new HashMap<String, Object>() {{
                put(Library.OPTION_TYPE_MAPPER, new GTypeMapper());
            }});    
    
    Pointer g_bytes_new(Pointer source, int size);
    Pointer g_bytes_get_data(Pointer bytes, LongByReference size);
    int g_bytes_get_size(Pointer bytes);
    Pointer g_bytes_ref(Pointer bytes);
    void g_bytes_unref(Pointer bytes);    
}
