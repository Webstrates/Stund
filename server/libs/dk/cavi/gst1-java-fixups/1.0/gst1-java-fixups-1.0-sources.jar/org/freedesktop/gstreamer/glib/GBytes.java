/*
 * Copyright (c) 2023 Jan Weber
 *
 * This file is part of gstreamer-java.
 *
 * This code is free software: you can redistribute it and/or modify it under the terms of the GNU
 * Lesser General Public License version 3 only, as published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License version 3 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License version 3 along with
 * this work. If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: LGPL-3.0-only
 */
package org.freedesktop.gstreamer.glib;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.LongByReference;
import org.freedesktop.gstreamer.lowlevel.GPointer;

import static org.freedesktop.gstreamer.lowlevel.GlibAPIExtended.GLIB_API;

/**
 * Wrapper to the GBytes data structure,
 * see <a href="https://docs.gtk.org/glib/struct.Bytes.html">https://docs.gtk.org/glib/struct.Bytes.html</a>
 */
public class GBytes extends RefCountedObject {

    public static final String GTYPE_NAME = "GBytes";

    GBytes(Initializer init) {
        super(new GBytes.Handle(init.ptr, init.ownsHandle), init.needRef);
    }

    GBytes(Handle handle) {
        super(handle);
    }

    public int getSize() {
        return GLIB_API.g_bytes_get_size(getRawPointer());
    }

    public byte[] getBytes() {
        LongByReference size = new LongByReference();
        Pointer bytes = GLIB_API.g_bytes_get_data(getRawPointer(), size);
        return bytes != null ? bytes.getByteArray(0, (int) size.getValue()) : new byte[0];
    }

    /**
     * Creates a GBytes instance from a sub-section of a byte array.
     * @param bytes  The source array.
     * @param offset The starting position in the source array.
     * @param length The number of bytes to copy.
     * @return A new GBytes instance.
     */
    public static GBytes createInstance(byte[] bytes, int offset, int length) {
        // Allocate native memory specifically for the 'length' we want to copy
        Pointer source = new Memory(length);

        // write(long peerOffset, byte[] buf, int arrayOffset, int len)
        source.write(0, bytes, offset, length);

        Pointer ptr = GLIB_API.g_bytes_new(source, length);

        return new GBytes(new Handle(new GPointer(ptr), true));
    }

    /**
     * Creates a GBytes instance from the full byte array.
     */
    public static GBytes createInstance(byte[] bytes) {
        return createInstance(bytes, 0, bytes.length);
    }

    private static final class Handle extends RefCountedObject.Handle {

        Handle(GPointer ptr, boolean ownsHandle) {
            super(ptr, ownsHandle);
        }

        @Override
        protected void disposeNativeHandle(GPointer ptr) {
            GLIB_API.g_bytes_unref(ptr.getPointer());
        }

        @Override
        protected void ref() {
            GLIB_API.g_bytes_ref(getPointer().getPointer());
        }

        @Override
        protected void unref() {
            GLIB_API.g_bytes_unref(getPointer().getPointer());
        }

    }

}