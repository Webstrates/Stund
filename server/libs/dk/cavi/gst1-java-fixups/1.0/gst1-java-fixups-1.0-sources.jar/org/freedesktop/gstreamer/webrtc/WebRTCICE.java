/*
 * Copyright (c) 2026 Janus Kristensen - CAVI, Center for Advanced
 * Visualization and Interaction - Aarhus University
 *
 * This file is part of gst1-java-fixups.
 *
 * This code is free software: you can redistribute it and/or modify it under the terms of the GNU
 * Lesser General Public License version 3 only, as published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License version 3 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License version 3 along with
 * this work. If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: LGPL-3.0-only
 */
package org.freedesktop.gstreamer.webrtc;

import java.util.stream.Stream;
import org.freedesktop.gstreamer.Gst;
import org.freedesktop.gstreamer.GstObject;
import org.freedesktop.gstreamer.glib.NativeObject;
import static org.freedesktop.gstreamer.glib.Natives.registration;

/**
 *
 * @see https://gitlab.freedesktop.org/gstreamer/gst-plugins-bad/blob/master/ext/webrtc/gstwebrtcice.h
 * available since Gstreamer 1.20
 */
@Gst.Since(minor = 20)
public class WebRTCICE extends GstObject {
    public static final String GTYPE_NAME = "GstWebRTCICE";

    public WebRTCICE(Initializer init) {
        super(init);
    }
    
    public static class Types implements NativeObject.TypeProvider {
        @Override
        public Stream<NativeObject.TypeRegistration<?>> types() {
            System.out.println("Registered WebRTCICE custom type");
            
            return Stream.of(
                registration(WebRTCICE.class, WebRTCICE.GTYPE_NAME, WebRTCICE::new)
            );
        }
    }    
    
}